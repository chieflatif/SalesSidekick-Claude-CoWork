---
name: airtable-crm
description: >
  This skill defines the Airtable CRM structure used as Chief's system of
  record. Use when reading from or writing to Airtable, managing deals,
  updating pipeline status, tracking prospects, or working with content
  scheduling data.
metadata:
  version: "1.0.0"
---

# Airtable CRM — System of Record

**Base ID:** `appLQ9oeCLC3Haizt` (Rebel CRM)

Airtable is the single source of truth for CRM, pipeline, content tracking, and research. n8n workflows write raw data (scraped content, transcripts). Claude reads, evaluates, scores, and writes intelligence back.

## Core CRM Tables

### Contacts (`tblhWpEGIlUB4kvIO`) — 10,360 records
Apollo-enriched prospect database. Primary key: Email.

Key fields: First Name, Last Name, Email, Title, Company, LinkedIn URL, Phone, Source, Enrichment Status, Email Validation Status, Intent Score, Priority Tier, Apollo Match Tier, Kajabi Tags, Member Status, HeyReach Campaign, Instantly Campaign

### Deals (`tblU11AqwlBbvDg6l`)
Full MEDDPICC-scored pipeline. Linked to Contacts and Activities.

| Field | Type | Values |
|-------|------|--------|
| Deal Name | Text | Company + opportunity |
| Type | Select | — |
| Stage | Select | Discovery / Qualification / Demo / Proposal / Negotiation / Closed Won / Closed Lost |
| Value | Currency | Deal value |
| Expected Close | Date | Target close |
| M - Metrics | Select | Red / Yellow / Green |
| E - Economic Buyer | Select | Red / Yellow / Green |
| D - Decision Criteria | Select | Red / Yellow / Green |
| D - Decision Process | Select | Red / Yellow / Green |
| P - Paper Process | Select | Red / Yellow / Green |
| I - Identify Pain | Select | Red / Yellow / Green |
| C - Champion | Select | Red / Yellow / Green |
| C - Competition | Select | Red / Yellow / Green |
| MEDDPICC Confidence | Select | High / Medium / Low |
| Forecast Category | Select | Commit / Best Case / Pipeline / Omitted |
| Deal Risk | Select | High / Medium / Low |
| Primary Competitor | Select | Salesforce Einstein / Gong / Generalist AI / Outreach/Salesloft / HubSpot AI / Clari / People.ai / Meeting Notes Tools / No Competition / Unknown |
| MEDDPICC Notes | Long text | Per-element notes, updated after calls |
| Contacts | Link | → Contacts table |
| Activities | Link | → Activities table |
| Probability | Number | Win probability % |
| Next Step | Text | Single next action |

### Activities (`tbl1GGwpxnCd8NoJk`)
Call, email, and meeting logs. Linked from Deals. Fed by call processing output.

| Field | Type | Description |
|-------|------|-------------|
| Subject | Text | Activity subject line |
| Contact | Link | → Contacts table |
| Activity Type | Select | Call / Email / Meeting / Note / Task |
| Direction | Select | Inbound / Outbound |
| Medium | Select | Phone / Video / Email / In Person / Chat |
| Notes | Long text | Full notes |
| Campaign Name | Text | If part of a sequence |
| Recording URL | URL | Link to call recording |
| Key Takeaways | Long text | AI-extracted takeaways |
| Next Steps | Long text | AI-extracted next steps |
| Pain Points | Long text | AI-extracted pain points |
| Deal | Link | → Deals table (auto-created via inverse link) |

## Content Pipeline Tables

### Research Items (`tbl5tLDEEZ0MPpYUU`)
Raw research from all sources. Fed by Tavily (Claude), Apify YouTube/LinkedIn (n8n).

| Field | Type | Description |
|-------|------|-------------|
| Title | Text | Headline/summary |
| Source Type | Select | YouTube Transcript / LinkedIn Post / Reddit Thread / Web Article / Newsletter / Podcast |
| Source URL | URL | Original link |
| Creator | Text | Author name |
| Content Summary | Long text | AI summary |
| Key Topics | Multi-select | Sales Methodology / AI in Sales / Pipeline Management / Cold Outreach / Discovery Calls / Closing / Sales Leadership / Revenue Operations / Tech Stack / Content Strategy / Personal Brand / Entrepreneurship |
| Relevance Score | Number | 1-10 |
| Sales Lens Translation | Long text | Sales practitioner angle |
| Status | Select | Raw / Evaluated / Translation Ready / Translated / Used / Rejected |
| Scraped Date | Date | When discovered |
| Quotes | Long text | Notable quotes |
| Evidence Claims | Long text | Factual claims/data points |

### Content Calendar (`tblrQADeQWmnEl6h4`)
Master editorial calendar across all brands.

| Field | Type | Description |
|-------|------|-------------|
| Content Title | Text | Working title |
| Brand | Select | Pipeline Rebel / SalesSidekick / Chief Latif |
| Content Type | Select | Newsletter / LinkedIn Post / Twitter Thread / Carousel / Video Script / Andy Script / Blog Post |
| Status | Select | Idea / Researching / Drafting / Review / Approved / Scheduled / Published / Repurposed |
| Publish Date | Date | Target/actual date |
| Topic | Text | Core angle |
| Hook | Text | Opening hook |
| Brief | Long text | Full content brief |
| Research Sources | Link | → Research Items |
| Outputs | Link | → Content Outputs |
| Influencer Sources | Link | → Influencer Digests |

### Content Outputs (`tblKDNoWBZNeWSnDO`)
Finished content ready for publishing.

| Field | Type | Description |
|-------|------|-------------|
| Title | Text | Final title |
| Content Type | Select | Newsletter HTML / LinkedIn Post / Twitter Thread / Carousel JSON / Video Script / Andy Script / Blog Post |
| Brand | Select | Pipeline Rebel / SalesSidekick / Chief Latif |
| Body | Long text | The actual content |
| Status | Select | Draft / Approved / Published / Repurposing |
| Published Date | Date | When published |
| Published URL | URL | Link to published version |
| Quality Score | Number | 0-100 critic score |
| Content Calendar | Link | → Content Calendar (auto-created inverse) |

### Influencer Digests (`tblrrRHIBJEymPCKI`)
Tracked creator content. Fed by n8n Apify scrapers.

| Field | Type | Description |
|-------|------|-------------|
| Creator Name | Text | Influencer name |
| Platform | Select | YouTube / LinkedIn / Twitter/X / Substack / Podcast |
| Profile URL | URL | Channel/profile link |
| Content Title | Text | Specific content title |
| Content URL | URL | Direct link |
| Content Date | Date | Published date |
| Transcript | Long text | Full text/transcript |
| Key Topics | Multi-select | Sales Methodology / AI in Sales / Pipeline Management / Cold Outreach / Discovery / Closing / Leadership / Revenue Ops / Content Strategy / Personal Brand |
| Relevance Score | Number | 1-10 |
| Engagement | Text | likes/comments/shares |
| Status | Select | Scraped / Evaluated / Translation Ready / Translated / Used / Skipped |
| Sales Lens Notes | Long text | Sales practitioner translation |

## Data Flow Architecture

```
n8n (Data Acquisition)          Claude (Intelligence)
─────────────────────          ──────────────────────
Apify YouTube scrape ──────→   Influencer Digests
Apify LinkedIn scrape ─────→   Influencer Digests
                               Tavily research ────→ Research Items
                               Evaluate + Score ───→ Update records
                               Plan content ───────→ Content Calendar
                               Draft content ──────→ Content Outputs
                               Process calls ──────→ Activities
                               Score deals ────────→ Deals (MEDDPICC)
```

## Write Protocol

When writing to Airtable:
1. Always use the table ID, not the name
2. For upserts, match on URL fields (Content URL, Source URL) to prevent duplicates
3. Set Status fields explicitly — don't leave blank
4. When updating MEDDPICC, always update MEDDPICC Notes with reasoning
5. Link records where possible (Deals → Contacts, Activities → Deals, Calendar → Research)

## Sync Protocol

- Airtable is canonical for structured data
- n8n writes raw data, Claude writes intelligence
- If Airtable is unavailable, note the pending write and retry next session
